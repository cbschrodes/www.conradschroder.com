{
	"patcher" : 	{
		"fileversion" : 1,
		"appversion" : 		{
			"major" : 8,
			"minor" : 6,
			"revision" : 5,
			"architecture" : "x64",
			"modernui" : 1
		}
,
		"classnamespace" : "box",
		"rect" : [ 37.0, 87.0, 1330.0, 726.0 ],
		"bglocked" : 0,
		"openinpresentation" : 0,
		"default_fontsize" : 12.0,
		"default_fontface" : 0,
		"default_fontname" : "Arial",
		"gridonopen" : 1,
		"gridsize" : [ 15.0, 15.0 ],
		"gridsnaponopen" : 1,
		"objectsnaponopen" : 1,
		"statusbarvisible" : 2,
		"toolbarvisible" : 1,
		"lefttoolbarpinned" : 0,
		"toptoolbarpinned" : 0,
		"righttoolbarpinned" : 0,
		"bottomtoolbarpinned" : 0,
		"toolbars_unpinned_last_save" : 0,
		"tallnewobj" : 0,
		"boxanimatetime" : 200,
		"enablehscroll" : 1,
		"enablevscroll" : 1,
		"devicewidth" : 0.0,
		"description" : "",
		"digest" : "",
		"tags" : "",
		"style" : "",
		"subpatcher_template" : "",
		"assistshowspatchername" : 0,
		"boxes" : [ 			{
				"box" : 				{
					"id" : "obj-113",
					"maxclass" : "number",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "", "bang" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 98.3333340883255, 332.000009894371033, 50.0, 22.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 650.0, 130.666668057441711, 50.0, 22.0 ]
				}

			}
, 			{
				"box" : 				{
					"bubble_bgcolor" : [ 1.0, 0.6, 0.6, 1.0 ],
					"fontface" : 1,
					"fontname" : "Arial Black",
					"fontsize" : 36.0,
					"id" : "obj-96",
					"linecount" : 2,
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 1660.0, 694.0, 479.0, 108.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 405.0, 42.666668057441711, 578.0, 57.0 ],
					"text" : "DRUM N' BASS MACHINE",
					"textcolor" : [ 0.741176470588235, 0.16078431372549, 0.16078431372549, 1.0 ]
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-91",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 1696.0, 669.0, 177.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 923.0, 331.333340525627136, 112.0, 23.0 ],
					"text" : "Change Scale"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-89",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 1717.5, 580.000017285346985, 179.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 1019.0, 156.333340525627136, 96.0, 23.0 ],
					"text" : "Bass Volume"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-76",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 1826.0, 924.0, 180.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 270.0, 440.333340525627136, 95.0, 23.0 ],
					"text" : "Open Hat Vol"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-74",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 1838.0, 958.0, 183.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 363.0, 440.333340525627136, 79.0, 23.0 ],
					"text" : "Hi Hat Vol"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-64",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 1912.0, 882.0, 180.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 514.0, 440.333340525627136, 65.0, 23.0 ],
					"text" : "Clap Vol"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-58",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 1748.0, 856.0, 179.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 444.0, 440.333340525627136, 72.0, 23.0 ],
					"text" : "Snare Vol"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-48",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 1712.0, 830.0, 190.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 205.0, 440.333340525627136, 68.0, 23.0 ],
					"text" : "Kick Vol"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-45",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 1676.0, 688.0, 176.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 1016.0, 49.333340525627136, 91.0, 23.0 ],
					"text" : "Audio On/Off"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-11",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 197.333339214324951, 16.0, 130.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 172.0, 63.666668057441711, 127.0, 23.0 ],
					"text" : "Metronome On/Off"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-7",
					"maxclass" : "toggle",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "int" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 286.666675209999084, 45.333334684371948, 24.0, 24.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 202.0, 88.666668057441711, 48.0, 48.0 ]
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-71",
					"maxclass" : "newobj",
					"numinlets" : 2,
					"numoutlets" : 1,
					"outlettype" : [ "bang" ],
					"patching_rect" : [ 681.333353638648987, 84.000002503395081, 119.0, 22.0 ],
					"text" : "metro 16n @active 1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-70",
					"maxclass" : "message",
					"numinlets" : 2,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 606.666684746742249, 84.000002503395081, 59.0, 22.0 ],
					"text" : "tempo $1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-63",
					"maxclass" : "number",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "", "bang" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 346.666676998138428, 46.666668057441711, 50.0, 22.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 261.0, 101.666668057441711, 50.0, 22.0 ]
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-50",
					"maxclass" : "newobj",
					"numinlets" : 2,
					"numoutlets" : 9,
					"outlettype" : [ "int", "int", "float", "float", "float", "", "int", "float", "" ],
					"patching_rect" : [ 561.3333500623703, 118.666670203208923, 183.0, 22.0 ],
					"text" : "transport"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-52",
					"maxclass" : "message",
					"numinlets" : 2,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 521.333348870277405, 29.33333420753479, 73.0, 22.0 ],
					"text" : "timesig $1 4"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-57",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 430.666679501533508, 22.666667342185974, 70.0, 22.0 ],
					"text" : "loadmess 3"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-44",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 881.333359599113464, 540.000016093254089, 179.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 686.0, 328.333340525627136, 179.0, 23.0 ],
					"text" : "Bass adsr env"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-28",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "float", "bang" ],
					"patching_rect" : [ 25.3333340883255, 298.666675567626953, 132.0, 22.0 ],
					"text" : "buffer~ sample5 clap1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-21",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "float", "bang" ],
					"patching_rect" : [ 25.3333340883255, 274.666674852371216, 140.0, 22.0 ],
					"text" : "buffer~ sample4 snare1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-17",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "float", "bang" ],
					"patching_rect" : [ 25.3333340883255, 248.000007390975952, 123.0, 22.0 ],
					"text" : "buffer~ sample3 hh1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-15",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "float", "bang" ],
					"patching_rect" : [ 25.3333340883255, 222.666673302650452, 123.0, 22.0 ],
					"text" : "buffer~ sample2 oh1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-14",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "float", "bang" ],
					"patching_rect" : [ 25.3333340883255, 198.666672587394714, 130.0, 22.0 ],
					"text" : "buffer~ sample1 kick1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-2",
					"items" : [ "presets", ",", 1, ",", 2, ",", 3 ],
					"maxclass" : "umenu",
					"numinlets" : 1,
					"numoutlets" : 3,
					"outlettype" : [ "int", "", "" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 53.333334922790527, 458.0, 100.0, 22.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 600.0, 101.666668057441711, 100.0, 22.0 ]
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-99",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "bang" ],
					"patching_rect" : [ 764.000022768974304, 332.000009894371033, 22.0, 22.0 ],
					"text" : "t b"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-95",
					"local" : 1,
					"maxclass" : "ezdac~",
					"numinlets" : 2,
					"numoutlets" : 0,
					"patching_rect" : [ 1062.666698336601257, 789.333356857299805, 45.0, 45.0 ]
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-94",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "signal" ],
					"patching_rect" : [ 985.333362698554993, 441.333346486091614, 31.0, 22.0 ],
					"text" : "sig~"
				}

			}
, 			{
				"box" : 				{
					"coll_data" : 					{
						"count" : 7,
						"data" : [ 							{
								"key" : 1,
								"value" : [ 0 ]
							}
, 							{
								"key" : 2,
								"value" : [ 2 ]
							}
, 							{
								"key" : 3,
								"value" : [ 3 ]
							}
, 							{
								"key" : 4,
								"value" : [ 5 ]
							}
, 							{
								"key" : 6,
								"value" : [ 7 ]
							}
, 							{
								"key" : 7,
								"value" : [ 9 ]
							}
, 							{
								"key" : 8,
								"value" : [ 10 ]
							}
 ]
					}
,
					"id" : "obj-88",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 4,
					"outlettype" : [ "", "", "", "" ],
					"patching_rect" : [ 1101.33336615562439, 242.666673898696899, 67.0, 22.0 ],
					"saved_object_attributes" : 					{
						"embed" : 1,
						"precision" : 6
					}
,
					"text" : "coll minor1"
				}

			}
, 			{
				"box" : 				{
					"coll_data" : 					{
						"count" : 7,
						"data" : [ 							{
								"key" : 1,
								"value" : [ 0 ]
							}
, 							{
								"key" : 2,
								"value" : [ 2 ]
							}
, 							{
								"key" : 3,
								"value" : [ 4 ]
							}
, 							{
								"key" : 4,
								"value" : [ 5 ]
							}
, 							{
								"key" : 6,
								"value" : [ 7 ]
							}
, 							{
								"key" : 7,
								"value" : [ 9 ]
							}
, 							{
								"key" : 8,
								"value" : [ 11 ]
							}
 ]
					}
,
					"id" : "obj-80",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 4,
					"outlettype" : [ "", "", "", "" ],
					"patching_rect" : [ 1101.33336615562439, 212.000006318092346, 67.0, 22.0 ],
					"saved_object_attributes" : 					{
						"embed" : 1,
						"precision" : 6
					}
,
					"text" : "coll major1"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-72",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 209.33333957195282, 120.000003576278687, 180.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 220.0, 153.333340525627136, 180.0, 23.0 ],
					"text" : "16 Step Drum Sequencer"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-67",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 764.000022768974304, 150.66667115688324, 183.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 686.0, 156.333340525627136, 183.0, 23.0 ],
					"text" : "Bass Appegiator"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-65",
					"maxclass" : "message",
					"numinlets" : 2,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 53.333334922790527, 350.0, 35.0, 22.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 600.0, 130.666668057441711, 45.0, 22.0 ],
					"text" : "store"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-60",
					"maxclass" : "preset",
					"numinlets" : 1,
					"numoutlets" : 5,
					"outlettype" : [ "preset", "int", "preset", "int", "" ],
					"patching_rect" : [ 53.333334922790527, 386.0, 100.0, 40.0 ],
					"preset_data" : [ 						{
							"number" : 1,
							"data" : [ 244, "obj-8", "matrixctrl", "list", 0, 0, 1.0, 0, 1, 0.0, 0, 2, 1.0, 0, 3, 0.0, 0, 4, 0.0, 1, 0, 0.0, 1, 1, 0.0, 1, 2, 1.0, 1, 3, 0.0, 1, 4, 0.0, 2, 0, 0.0, 2, 1, 0.0, 2, 2, 1.0, 2, 3, 0.0, 2, 4, 0.0, 3, 0, 0.0, 3, 1, 0.0, 3, 2, 1.0, 3, 3, 0.0, 3, 4, 0.0, 4, 0, 1.0, 4, 1, 0.0, 4, 2, 1.0, 4, 3, 0.0, 4, 4, 1.0, 5, 0, 0.0, 5, 1, 0.0, 5, 2, 1.0, 5, 3, 0.0, 5, 4, 0.0, 6, 0, 0.0, 6, 1, 0.0, 6, 2, 1.0, 6, 3, 0.0, 6, 4, 0.0, 7, 0, 0.0, 7, 1, 0.0, 7, 2, 1.0, 7, 3, 0.0, 7, 4, 0.0, 8, 0, 1.0, 8, 1, 0.0, 8, 2, 1.0, 8, 3, 0.0, 8, 4, 0.0, 9, 0, 0.0, 9, 1, 0.0, 9, 2, 1.0, 9, 3, 0.0, 9, 4, 0.0, 10, 0, 0.0, 10, 1, 0.0, 10, 2, 1.0, 10, 3, 0.0, 10, 4, 0.0, 11, 0, 0.0, 11, 1, 0.0, 11, 2, 1.0, 11, 3, 0.0, 11, 4, 0.0, 12, 0, 1.0, 12, 1, 0.0, 12, 2, 1.0, 12, 3, 0.0, 12, 4, 1.0, 13, 0, 0.0, 13, 1, 0.0, 13, 2, 1.0, 13, 3, 0.0, 13, 4, 0.0, 14, 0, 0.0, 14, 1, 0.0, 14, 2, 1.0, 14, 3, 0.0, 14, 4, 0.0, 15, 0, 0.0, 15, 1, 0.0, 15, 2, 1.0, 15, 3, 0.0, 15, 4, 0.0, 5, "obj-68", "live.gain~", "float", 2.409448862075806, 5, "obj-84", "live.gain~", "float", 0.0, 5, "obj-85", "live.gain~", "float", 0.0, 5, "obj-86", "live.gain~", "float", 0.0, 5, "obj-87", "live.gain~", "float", -5.033992767333984, 11, "obj-1", "multislider", "list", 5, 4, 7, 4, 3, 5, 5, 4, "obj-24", "function", "clear", 7, "obj-24", "function", "add", 5.319148936170213, 0.0, 0, 7, "obj-24", "function", "add", 58.51063829787234, 1.0, 0, 7, "obj-24", "function", "add", 58.51063829787234, 1.0, 0, 7, "obj-24", "function", "add", 170.212765957446805, 0.573333333333333, 0, 7, "obj-24", "function", "add", 175.531914893617028, 0.306666666666667, 0, 7, "obj-24", "function", "add", 260.638297872340445, 0.0, 0, 5, "obj-24", "function", "domain", 1000.0, 6, "obj-24", "function", "range", 0.0, 1.0, 5, "obj-24", "function", "mode", 0, 5, "obj-29", "live.gain~", "float", 0.0, 5, "obj-42", "umenu", "int", 1, 5, "obj-2", "umenu", "int", 0, 5, "obj-63", "number", "int", 120, 5, "obj-7", "toggle", "int", 1 ]
						}
, 						{
							"number" : 2,
							"data" : [ 244, "obj-8", "matrixctrl", "list", 0, 0, 1.0, 0, 1, 0.0, 0, 2, 1.0, 0, 3, 0.0, 0, 4, 0.0, 1, 0, 0.0, 1, 1, 0.0, 1, 2, 1.0, 1, 3, 0.0, 1, 4, 0.0, 2, 0, 0.0, 2, 1, 1.0, 2, 2, 1.0, 2, 3, 0.0, 2, 4, 0.0, 3, 0, 0.0, 3, 1, 0.0, 3, 2, 1.0, 3, 3, 0.0, 3, 4, 0.0, 4, 0, 1.0, 4, 1, 0.0, 4, 2, 1.0, 4, 3, 0.0, 4, 4, 1.0, 5, 0, 0.0, 5, 1, 0.0, 5, 2, 1.0, 5, 3, 0.0, 5, 4, 0.0, 6, 0, 0.0, 6, 1, 1.0, 6, 2, 1.0, 6, 3, 0.0, 6, 4, 0.0, 7, 0, 0.0, 7, 1, 0.0, 7, 2, 1.0, 7, 3, 0.0, 7, 4, 0.0, 8, 0, 1.0, 8, 1, 0.0, 8, 2, 1.0, 8, 3, 0.0, 8, 4, 0.0, 9, 0, 0.0, 9, 1, 0.0, 9, 2, 1.0, 9, 3, 0.0, 9, 4, 0.0, 10, 0, 0.0, 10, 1, 1.0, 10, 2, 1.0, 10, 3, 0.0, 10, 4, 0.0, 11, 0, 0.0, 11, 1, 0.0, 11, 2, 1.0, 11, 3, 1.0, 11, 4, 0.0, 12, 0, 1.0, 12, 1, 0.0, 12, 2, 1.0, 12, 3, 0.0, 12, 4, 1.0, 13, 0, 0.0, 13, 1, 0.0, 13, 2, 1.0, 13, 3, 0.0, 13, 4, 0.0, 14, 0, 0.0, 14, 1, 1.0, 14, 2, 1.0, 14, 3, 0.0, 14, 4, 0.0, 15, 0, 0.0, 15, 1, 0.0, 15, 2, 1.0, 15, 3, 0.0, 15, 4, 0.0, 5, "obj-68", "live.gain~", "float", 2.409448862075806, 5, "obj-84", "live.gain~", "float", 0.0, 5, "obj-85", "live.gain~", "float", 0.0, 5, "obj-86", "live.gain~", "float", 0.0, 5, "obj-87", "live.gain~", "float", -5.033992767333984, 11, "obj-1", "multislider", "list", 7, 4, 7, 4, 5, 3, 2, 4, "obj-24", "function", "clear", 7, "obj-24", "function", "add", 26.595744680851062, 0.0, 0, 7, "obj-24", "function", "add", 53.191489361702125, 1.0, 0, 7, "obj-24", "function", "add", 175.531914893617028, 0.6, 0, 7, "obj-24", "function", "add", 478.723404255319167, 0.506666666666667, 0, 7, "obj-24", "function", "add", 654.255319148936223, 0.0, 0, 5, "obj-24", "function", "domain", 1000.0, 6, "obj-24", "function", "range", 0.0, 1.0, 5, "obj-24", "function", "mode", 0, 5, "obj-29", "live.gain~", "float", 0.0, 5, "obj-42", "umenu", "int", 1, 5, "obj-2", "umenu", "int", 0, 5, "obj-63", "number", "int", 120, 5, "obj-7", "toggle", "int", 1 ]
						}
, 						{
							"number" : 3,
							"data" : [ 244, "obj-8", "matrixctrl", "list", 0, 0, 1.0, 0, 1, 0.0, 0, 2, 1.0, 0, 3, 0.0, 0, 4, 0.0, 1, 0, 0.0, 1, 1, 0.0, 1, 2, 1.0, 1, 3, 0.0, 1, 4, 0.0, 2, 0, 0.0, 2, 1, 0.0, 2, 2, 1.0, 2, 3, 0.0, 2, 4, 0.0, 3, 0, 1.0, 3, 1, 0.0, 3, 2, 1.0, 3, 3, 0.0, 3, 4, 0.0, 4, 0, 0.0, 4, 1, 0.0, 4, 2, 1.0, 4, 3, 0.0, 4, 4, 0.0, 5, 0, 0.0, 5, 1, 0.0, 5, 2, 1.0, 5, 3, 0.0, 5, 4, 0.0, 6, 0, 1.0, 6, 1, 0.0, 6, 2, 1.0, 6, 3, 0.0, 6, 4, 0.0, 7, 0, 0.0, 7, 1, 0.0, 7, 2, 1.0, 7, 3, 0.0, 7, 4, 0.0, 8, 0, 0.0, 8, 1, 0.0, 8, 2, 1.0, 8, 3, 1.0, 8, 4, 0.0, 9, 0, 0.0, 9, 1, 0.0, 9, 2, 1.0, 9, 3, 0.0, 9, 4, 0.0, 10, 0, 0.0, 10, 1, 0.0, 10, 2, 1.0, 10, 3, 0.0, 10, 4, 0.0, 11, 0, 0.0, 11, 1, 0.0, 11, 2, 1.0, 11, 3, 0.0, 11, 4, 0.0, 12, 0, 0.0, 12, 1, 0.0, 12, 2, 1.0, 12, 3, 0.0, 12, 4, 0.0, 13, 0, 0.0, 13, 1, 0.0, 13, 2, 1.0, 13, 3, 0.0, 13, 4, 0.0, 14, 0, 0.0, 14, 1, 0.0, 14, 2, 1.0, 14, 3, 1.0, 14, 4, 0.0, 15, 0, 1.0, 15, 1, 0.0, 15, 2, 1.0, 15, 3, 0.0, 15, 4, 0.0, 5, "obj-68", "live.gain~", "float", 2.409448862075806, 5, "obj-84", "live.gain~", "float", 0.0, 5, "obj-85", "live.gain~", "float", 0.0, 5, "obj-86", "live.gain~", "float", 0.0, 5, "obj-87", "live.gain~", "float", -5.033992767333984, 11, "obj-1", "multislider", "list", 1, 1, 1, 1, 1, 6, 6, 4, "obj-24", "function", "clear", 7, "obj-24", "function", "add", 26.595744680851062, 0.0, 0, 7, "obj-24", "function", "add", 53.191489361702125, 1.0, 0, 7, "obj-24", "function", "add", 175.531914893617028, 0.6, 0, 7, "obj-24", "function", "add", 478.723404255319167, 0.506666666666667, 0, 7, "obj-24", "function", "add", 654.255319148936223, 0.0, 0, 5, "obj-24", "function", "domain", 1000.0, 6, "obj-24", "function", "range", 0.0, 1.0, 5, "obj-24", "function", "mode", 0, 5, "obj-29", "live.gain~", "float", 0.0, 5, "obj-42", "umenu", "int", 2, 5, "obj-2", "umenu", "int", 0, 5, "obj-63", "number", "int", 120, 5, "obj-7", "toggle", "int", 1 ]
						}
 ]
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-59",
					"maxclass" : "message",
					"numinlets" : 2,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 844.000025153160095, 512.000015258789062, 35.0, 22.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 851.0, 459.0, 35.0, 22.0 ],
					"text" : "clear"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-42",
					"items" : [ "scales", ",", "refer", "major1", ",", "refer", "minor1" ],
					"maxclass" : "umenu",
					"numinlets" : 1,
					"numoutlets" : 3,
					"outlettype" : [ "int", "", "" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 1101.33336615562439, 180.00000536441803, 100.0, 22.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 923.0, 359.333340525627136, 100.0, 22.0 ]
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-41",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 986.666696071624756, 408.000012159347534, 32.0, 22.0 ],
					"text" : "mtof"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-40",
					"maxclass" : "newobj",
					"numinlets" : 2,
					"numoutlets" : 1,
					"outlettype" : [ "int" ],
					"patching_rect" : [ 986.666696071624756, 378.666677951812744, 32.0, 22.0 ],
					"text" : "+ 36"
				}

			}
, 			{
				"box" : 				{
					"coll_data" : 					{
						"count" : 7,
						"data" : [ 							{
								"key" : 1,
								"value" : [ 0 ]
							}
, 							{
								"key" : 2,
								"value" : [ 2 ]
							}
, 							{
								"key" : 3,
								"value" : [ 3 ]
							}
, 							{
								"key" : 4,
								"value" : [ 5 ]
							}
, 							{
								"key" : 6,
								"value" : [ 7 ]
							}
, 							{
								"key" : 7,
								"value" : [ 9 ]
							}
, 							{
								"key" : 8,
								"value" : [ 10 ]
							}
 ]
					}
,
					"id" : "obj-39",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 4,
					"outlettype" : [ "", "", "", "" ],
					"patching_rect" : [ 986.666696071624756, 344.000010251998901, 64.0, 22.0 ],
					"saved_object_attributes" : 					{
						"embed" : 1,
						"precision" : 6
					}
,
					"text" : "coll scales"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-38",
					"maxclass" : "newobj",
					"numinlets" : 2,
					"numoutlets" : 1,
					"outlettype" : [ "signal" ],
					"patching_rect" : [ 941.333359599113464, 500.000014901161194, 30.0, 22.0 ],
					"text" : "*~ 1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-29",
					"lastchannelcount" : 0,
					"maxclass" : "live.gain~",
					"numinlets" : 2,
					"numoutlets" : 5,
					"outlettype" : [ "signal", "signal", "", "float", "list" ],
					"parameter_enable" : 1,
					"patching_rect" : [ 1107.0, 638.333355069160461, 48.0, 136.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 1037.0, 185.333340525627136, 48.0, 136.0 ],
					"saved_attribute_attributes" : 					{
						"valueof" : 						{
							"parameter_longname" : "live.gain~[5]",
							"parameter_mmax" : 6.0,
							"parameter_mmin" : -70.0,
							"parameter_modmode" : 3,
							"parameter_shortname" : "live.gain~[5]",
							"parameter_type" : 0,
							"parameter_unitstyle" : 4
						}

					}
,
					"varname" : "live.gain~[5]"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-26",
					"maxclass" : "newobj",
					"numinlets" : 2,
					"numoutlets" : 2,
					"outlettype" : [ "signal", "bang" ],
					"patching_rect" : [ 881.333359599113464, 668.000019907951355, 34.0, 22.0 ],
					"text" : "line~"
				}

			}
, 			{
				"box" : 				{
					"addpoints" : [ 26.595744680851062, 0.0, 0, 53.191489361702125, 1.0, 0, 175.531914893617028, 0.6, 0, 478.723404255319167, 0.506666666666667, 0, 654.255319148936223, 0.0, 0 ],
					"classic_curve" : 1,
					"id" : "obj-24",
					"linecolor" : [ 1.0, 0.0, 0.0, 1.0 ],
					"maxclass" : "function",
					"numinlets" : 1,
					"numoutlets" : 4,
					"outlettype" : [ "float", "", "", "bang" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 830.666691422462463, 566.666683554649353, 200.0, 100.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 686.0, 354.333340525627136, 200.0, 100.0 ]
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-23",
					"maxclass" : "newobj",
					"numinlets" : 2,
					"numoutlets" : 1,
					"outlettype" : [ "signal" ],
					"patching_rect" : [ 985.333362698554993, 476.000014185905457, 37.0, 22.0 ],
					"text" : "saw~"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-18",
					"maxclass" : "newobj",
					"numinlets" : 5,
					"numoutlets" : 4,
					"outlettype" : [ "int", "", "", "int" ],
					"patching_rect" : [ 644.000019192695618, 257.333341002464294, 69.0, 22.0 ],
					"text" : "counter 1 8"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-20",
					"maxclass" : "message",
					"numinlets" : 2,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 644.000019192695618, 296.000008821487427, 51.0, 22.0 ],
					"text" : "fetch $1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-1",
					"maxclass" : "multislider",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "", "" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 750.666689038276672, 180.00000536441803, 337.0, 139.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 686.0, 183.333340525627136, 337.0, 139.0 ],
					"setminmax" : [ 1.0, 8.0 ],
					"settype" : 0,
					"size" : 7,
					"slidercolor" : [ 1.0, 0.0, 0.0, 1.0 ]
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-33",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 361.333344101905823, 24.000000715255737, 38.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 313.0, 101.166668057441711, 38.0, 23.0 ],
					"text" : "BPM"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-27",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 553.333349823951721, 297.33334219455719, 83.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 169.0, 291.333340525627136, 39.0, 23.0 ],
					"text" : "Clap"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-25",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 553.333349823951721, 269.333341360092163, 83.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 163.0, 266.333340525627136, 51.0, 23.0 ],
					"text" : "Snare"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-22",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 553.333349823951721, 213.333339691162109, 85.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 147.0, 210.0, 71.0, 23.0 ],
					"text" : "Open Hat"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-19",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 553.333349823951721, 241.333340525627136, 86.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 163.0, 238.333340525627136, 51.0, 23.0 ],
					"text" : "Hi Hat"
				}

			}
, 			{
				"box" : 				{
					"fontname" : "Arial Black",
					"id" : "obj-13",
					"maxclass" : "comment",
					"numinlets" : 1,
					"numoutlets" : 0,
					"patching_rect" : [ 553.333349823951721, 188.000005602836609, 89.0, 23.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 178.0, 183.333340525627136, 40.0, 23.0 ],
					"text" : "Kick"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-87",
					"lastchannelcount" : 0,
					"maxclass" : "live.gain~",
					"numinlets" : 2,
					"numoutlets" : 5,
					"outlettype" : [ "signal", "signal", "", "float", "list" ],
					"parameter_enable" : 1,
					"patching_rect" : [ 566.666683554649353, 576.000017166137695, 45.0, 80.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 524.0, 351.333340525627136, 45.0, 85.0 ],
					"saved_attribute_attributes" : 					{
						"valueof" : 						{
							"parameter_longname" : "live.gain~[4]",
							"parameter_mmax" : 6.0,
							"parameter_mmin" : -70.0,
							"parameter_modmode" : 3,
							"parameter_shortname" : "live.gain~",
							"parameter_type" : 0,
							"parameter_unitstyle" : 4
						}

					}
,
					"varname" : "live.gain~[4]"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-86",
					"lastchannelcount" : 0,
					"maxclass" : "live.gain~",
					"numinlets" : 2,
					"numoutlets" : 5,
					"outlettype" : [ "signal", "signal", "", "float", "list" ],
					"parameter_enable" : 1,
					"patching_rect" : [ 465.333347201347351, 576.000017166137695, 46.0, 80.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 457.0, 351.333340525627136, 46.0, 86.0 ],
					"saved_attribute_attributes" : 					{
						"valueof" : 						{
							"parameter_longname" : "live.gain~[3]",
							"parameter_mmax" : 6.0,
							"parameter_mmin" : -70.0,
							"parameter_modmode" : 3,
							"parameter_shortname" : "live.gain~",
							"parameter_type" : 0,
							"parameter_unitstyle" : 4
						}

					}
,
					"varname" : "live.gain~[3]"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-85",
					"lastchannelcount" : 0,
					"maxclass" : "live.gain~",
					"numinlets" : 2,
					"numoutlets" : 5,
					"outlettype" : [ "signal", "signal", "", "float", "list" ],
					"parameter_enable" : 1,
					"patching_rect" : [ 368.000010967254639, 576.000017166137695, 45.0, 81.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 380.0, 352.333340525627136, 45.0, 84.0 ],
					"saved_attribute_attributes" : 					{
						"valueof" : 						{
							"parameter_longname" : "live.gain~[2]",
							"parameter_mmax" : 6.0,
							"parameter_mmin" : -70.0,
							"parameter_modmode" : 3,
							"parameter_shortname" : "live.gain~",
							"parameter_type" : 0,
							"parameter_unitstyle" : 4
						}

					}
,
					"varname" : "live.gain~[2]"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-84",
					"lastchannelcount" : 0,
					"maxclass" : "live.gain~",
					"numinlets" : 2,
					"numoutlets" : 5,
					"outlettype" : [ "signal", "signal", "", "float", "list" ],
					"parameter_enable" : 1,
					"patching_rect" : [ 274.666674852371216, 580.000017285346985, 75.0, 78.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 285.0, 352.333340525627136, 75.0, 84.0 ],
					"saved_attribute_attributes" : 					{
						"valueof" : 						{
							"parameter_longname" : "live.gain~[1]",
							"parameter_mmax" : 6.0,
							"parameter_mmin" : -70.0,
							"parameter_modmode" : 3,
							"parameter_shortname" : "live.gain~",
							"parameter_type" : 0,
							"parameter_unitstyle" : 4
						}

					}
,
					"varname" : "live.gain~[1]"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-83",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "signal", "bang" ],
					"patching_rect" : [ 557.333349943161011, 541.333349466323853, 86.0, 22.0 ],
					"text" : "play~ sample5"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-82",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "signal", "bang" ],
					"patching_rect" : [ 461.333347082138062, 548.000016331672668, 86.0, 22.0 ],
					"text" : "play~ sample4"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-81",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "signal", "bang" ],
					"patching_rect" : [ 368.000010967254639, 541.333349466323853, 86.0, 22.0 ],
					"text" : "play~ sample3"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-79",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "signal", "bang" ],
					"patching_rect" : [ 274.666674852371216, 548.000016331672668, 86.0, 22.0 ],
					"text" : "play~ sample2"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-78",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "signal", "bang" ],
					"patching_rect" : [ 180.00000536441803, 541.333349466323853, 86.0, 22.0 ],
					"text" : "play~ sample1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-69",
					"local" : 1,
					"maxclass" : "ezdac~",
					"numinlets" : 2,
					"numoutlets" : 0,
					"patching_rect" : [ 249.333340764045715, 729.333355069160461, 45.0, 45.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 1029.0, 74.333340525627136, 64.0, 64.0 ]
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-68",
					"lastchannelcount" : 0,
					"maxclass" : "live.gain~",
					"numinlets" : 2,
					"numoutlets" : 5,
					"outlettype" : [ "signal", "signal", "", "float", "list" ],
					"parameter_enable" : 1,
					"patching_rect" : [ 176.00000524520874, 576.000017166137695, 82.0, 85.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 210.0, 351.333340525627136, 58.0, 85.0 ],
					"saved_attribute_attributes" : 					{
						"valueof" : 						{
							"parameter_longname" : "live.gain~",
							"parameter_mmax" : 6.0,
							"parameter_mmin" : -70.0,
							"parameter_modmode" : 3,
							"parameter_shortname" : "live.gain~",
							"parameter_type" : 0,
							"parameter_unitstyle" : 4
						}

					}
,
					"varname" : "live.gain~"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-62",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 561.3333500623703, 510.666681885719299, 63.0, 22.0 ],
					"text" : "prepend 1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-56",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 461.333347082138062, 510.666681885719299, 63.0, 22.0 ],
					"text" : "prepend 1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-55",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 368.000010967254639, 510.666681885719299, 63.0, 22.0 ],
					"text" : "prepend 1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-54",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 274.666674852371216, 510.666681885719299, 63.0, 22.0 ],
					"text" : "prepend 1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-53",
					"maxclass" : "newobj",
					"numinlets" : 2,
					"numoutlets" : 2,
					"outlettype" : [ "bang", "" ],
					"patching_rect" : [ 361.333344101905823, 418.66667914390564, 34.0, 22.0 ],
					"text" : "sel 1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-51",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 180.00000536441803, 510.666681885719299, 63.0, 22.0 ],
					"text" : "prepend 1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-16",
					"maxclass" : "newobj",
					"numinlets" : 2,
					"numoutlets" : 2,
					"outlettype" : [ "bang", "" ],
					"patching_rect" : [ 320.000009536743164, 418.66667914390564, 34.0, 22.0 ],
					"text" : "sel 1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-10",
					"maxclass" : "newobj",
					"numinlets" : 2,
					"numoutlets" : 2,
					"outlettype" : [ "bang", "" ],
					"patching_rect" : [ 274.666674852371216, 418.66667914390564, 34.0, 22.0 ],
					"text" : "sel 1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-9",
					"maxclass" : "newobj",
					"numinlets" : 2,
					"numoutlets" : 2,
					"outlettype" : [ "bang", "" ],
					"patching_rect" : [ 230.666673541069031, 418.66667914390564, 34.0, 22.0 ],
					"text" : "sel 1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-6",
					"maxclass" : "newobj",
					"numinlets" : 2,
					"numoutlets" : 2,
					"outlettype" : [ "bang", "" ],
					"patching_rect" : [ 194.666672468185425, 418.66667914390564, 34.0, 22.0 ],
					"text" : "sel 1"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-12",
					"maxclass" : "newobj",
					"numinlets" : 1,
					"numoutlets" : 5,
					"outlettype" : [ "float", "float", "float", "float", "float" ],
					"patching_rect" : [ 194.666672468185425, 361.333344101905823, 81.0, 22.0 ],
					"text" : "unpack f f f f f"
				}

			}
, 			{
				"box" : 				{
					"color" : [ 1.0, 0.0, 0.0, 1.0 ],
					"columns" : 16,
					"elementcolor" : [ 0.517647058823529, 0.537254901960784, 0.537254901960784, 1.0 ],
					"id" : "obj-8",
					"maxclass" : "matrixctrl",
					"numinlets" : 1,
					"numoutlets" : 2,
					"outlettype" : [ "list", "list" ],
					"parameter_enable" : 0,
					"patching_rect" : [ 197.333339214324951, 182.666672110557556, 349.0, 137.0 ],
					"presentation" : 1,
					"presentation_rect" : [ 220.0, 181.333340525627136, 349.0, 137.0 ],
					"rows" : 5
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-4",
					"maxclass" : "newobj",
					"numinlets" : 5,
					"numoutlets" : 4,
					"outlettype" : [ "int", "", "", "int" ],
					"patching_rect" : [ 25.3333340883255, 118.666670203208923, 75.0, 22.0 ],
					"text" : "counter 0 15"
				}

			}
, 			{
				"box" : 				{
					"id" : "obj-3",
					"maxclass" : "message",
					"numinlets" : 2,
					"numoutlets" : 1,
					"outlettype" : [ "" ],
					"patching_rect" : [ 25.3333340883255, 149.333337783813477, 81.0, 22.0 ],
					"text" : "getcolumn $1"
				}

			}
, 			{
				"box" : 				{
					"autofit" : 1,
					"id" : "obj-98",
					"maxclass" : "fpic",
					"numinlets" : 1,
					"numoutlets" : 1,
					"outlettype" : [ "jit_matrix" ],
					"patching_rect" : [ 1648.0, 812.0, 100.0, 76.953125 ],
					"pic" : "/Users/conradschroder/Downloads/10353673376_ec7a400972_b.jpg",
					"presentation" : 1,
					"presentation_rect" : [ 147.0, 29.0, 971.0, 479.0 ]
				}

			}
 ],
		"lines" : [ 			{
				"patchline" : 				{
					"destination" : [ "obj-39", 0 ],
					"midpoints" : [ 1078.166689038276672, 331.000007808208466, 996.166696071624756, 331.000007808208466 ],
					"order" : 0,
					"source" : [ "obj-1", 1 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-99", 0 ],
					"midpoints" : [ 1078.166689038276672, 325.000007629394531, 773.500022768974304, 325.000007629394531 ],
					"order" : 1,
					"source" : [ "obj-1", 1 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-55", 0 ],
					"source" : [ "obj-10", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-65", 1 ],
					"source" : [ "obj-113", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-10", 0 ],
					"source" : [ "obj-12", 2 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-16", 0 ],
					"source" : [ "obj-12", 3 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-53", 0 ],
					"source" : [ "obj-12", 4 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-6", 0 ],
					"source" : [ "obj-12", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-9", 0 ],
					"source" : [ "obj-12", 1 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-56", 0 ],
					"source" : [ "obj-16", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-20", 0 ],
					"source" : [ "obj-18", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-60", 0 ],
					"midpoints" : [ 103.333334922790527, 490.0, 43.083333730697632, 490.0, 43.083333730697632, 374.999997854232788, 62.833334922790527, 374.999997854232788 ],
					"source" : [ "obj-2", 1 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-1", 0 ],
					"midpoints" : [ 653.500019192695618, 335.333336353302002, 737.833330988883972, 335.333336353302002, 737.833330988883972, 172.333336353302002, 760.166689038276672, 172.333336353302002 ],
					"source" : [ "obj-20", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-38", 1 ],
					"source" : [ "obj-23", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-26", 0 ],
					"source" : [ "obj-24", 1 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-38", 0 ],
					"midpoints" : [ 890.833359599113464, 700.333336353302002, 815.583330988883972, 700.333336353302002, 815.583330988883972, 482.333336353302002, 950.833359599113464, 482.333336353302002 ],
					"source" : [ "obj-26", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-95", 1 ],
					"order" : 0,
					"source" : [ "obj-29", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-95", 0 ],
					"order" : 1,
					"source" : [ "obj-29", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-8", 0 ],
					"midpoints" : [ 34.8333340883255, 180.500005066394806, 206.833339214324951, 180.500005066394806 ],
					"source" : [ "obj-3", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-29", 0 ],
					"midpoints" : [ 950.833359599113464, 529.666684985160828, 1116.5, 529.666684985160828 ],
					"source" : [ "obj-38", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-40", 0 ],
					"source" : [ "obj-39", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-3", 0 ],
					"source" : [ "obj-4", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-41", 0 ],
					"source" : [ "obj-40", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-94", 0 ],
					"source" : [ "obj-41", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-39", 0 ],
					"midpoints" : [ 1151.33336615562439, 337.833336353302002, 996.166696071624756, 337.833336353302002 ],
					"source" : [ "obj-42", 1 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-18", 0 ],
					"source" : [ "obj-50", 5 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-4", 0 ],
					"midpoints" : [ 652.8333500623703, 154.666670322418213, 156.500003159046173, 154.666670322418213, 156.500003159046173, 107.666670203208923, 34.8333340883255, 107.666670203208923 ],
					"source" : [ "obj-50", 4 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-78", 0 ],
					"source" : [ "obj-51", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-50", 0 ],
					"midpoints" : [ 530.833348870277405, 89.166669011116028, 570.8333500623703, 89.166669011116028 ],
					"source" : [ "obj-52", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-62", 0 ],
					"source" : [ "obj-53", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-79", 0 ],
					"source" : [ "obj-54", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-81", 0 ],
					"source" : [ "obj-55", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-82", 0 ],
					"source" : [ "obj-56", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-52", 0 ],
					"midpoints" : [ 440.166679501533508, 55.000000715255737, 506.583348333835602, 55.000000715255737, 506.583348333835602, 18.33333420753479, 530.833348870277405, 18.33333420753479 ],
					"order" : 1,
					"source" : [ "obj-57", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-70", 0 ],
					"midpoints" : [ 440.166679501533508, 64.000001609325409, 616.166684746742249, 64.000001609325409 ],
					"order" : 0,
					"source" : [ "obj-57", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-24", 0 ],
					"midpoints" : [ 853.500025153160095, 549.833349406719208, 840.166691422462463, 549.833349406719208 ],
					"source" : [ "obj-59", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-51", 0 ],
					"midpoints" : [ 204.166672468185425, 438.307731032371521 ],
					"source" : [ "obj-6", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-83", 0 ],
					"source" : [ "obj-62", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-70", 0 ],
					"midpoints" : [ 356.166676998138428, 77.833335340023041, 616.166684746742249, 77.833335340023041 ],
					"source" : [ "obj-63", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-60", 0 ],
					"source" : [ "obj-65", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-69", 1 ],
					"midpoints" : [ 185.50000524520874, 694.666686117649078, 284.833340764045715, 694.666686117649078 ],
					"order" : 0,
					"source" : [ "obj-68", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-69", 0 ],
					"midpoints" : [ 185.50000524520874, 694.666686117649078, 258.833340764045715, 694.666686117649078 ],
					"order" : 1,
					"source" : [ "obj-68", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-50", 0 ],
					"midpoints" : [ 296.166675209999084, 98.166669249534607, 570.8333500623703, 98.166669249534607 ],
					"source" : [ "obj-7", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-50", 0 ],
					"midpoints" : [ 616.166684746742249, 116.500003159046173, 570.8333500623703, 116.500003159046173 ],
					"source" : [ "obj-70", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-50", 0 ],
					"midpoints" : [ 690.833353638648987, 116.500003159046173, 570.8333500623703, 116.500003159046173 ],
					"source" : [ "obj-71", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-68", 0 ],
					"source" : [ "obj-78", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-84", 0 ],
					"source" : [ "obj-79", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-12", 0 ],
					"source" : [ "obj-8", 1 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-85", 0 ],
					"source" : [ "obj-81", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-86", 0 ],
					"source" : [ "obj-82", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-87", 0 ],
					"source" : [ "obj-83", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-69", 1 ],
					"midpoints" : [ 284.166674852371216, 693.166686177253723, 284.833340764045715, 693.166686177253723 ],
					"order" : 0,
					"source" : [ "obj-84", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-69", 0 ],
					"midpoints" : [ 284.166674852371216, 693.166686177253723, 258.833340764045715, 693.166686177253723 ],
					"order" : 1,
					"source" : [ "obj-84", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-69", 1 ],
					"midpoints" : [ 377.500010967254639, 692.666686117649078, 284.833340764045715, 692.666686117649078 ],
					"order" : 0,
					"source" : [ "obj-85", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-69", 0 ],
					"midpoints" : [ 377.500010967254639, 692.666686117649078, 258.833340764045715, 692.666686117649078 ],
					"order" : 1,
					"source" : [ "obj-85", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-69", 1 ],
					"midpoints" : [ 474.833347201347351, 692.166686117649078, 284.833340764045715, 692.166686117649078 ],
					"order" : 0,
					"source" : [ "obj-86", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-69", 0 ],
					"midpoints" : [ 474.833347201347351, 692.166686117649078, 258.833340764045715, 692.166686117649078 ],
					"order" : 1,
					"source" : [ "obj-86", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-69", 1 ],
					"midpoints" : [ 576.166683554649353, 692.166686117649078, 284.833340764045715, 692.166686117649078 ],
					"order" : 0,
					"source" : [ "obj-87", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-69", 0 ],
					"midpoints" : [ 576.166683554649353, 692.166686117649078, 258.833340764045715, 692.166686117649078 ],
					"order" : 1,
					"source" : [ "obj-87", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-54", 0 ],
					"source" : [ "obj-9", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-23", 0 ],
					"source" : [ "obj-94", 0 ]
				}

			}
, 			{
				"patchline" : 				{
					"destination" : [ "obj-24", 0 ],
					"midpoints" : [ 773.500022768974304, 459.833346724510193, 840.166691422462463, 459.833346724510193 ],
					"source" : [ "obj-99", 0 ]
				}

			}
 ],
		"parameters" : 		{
			"obj-29" : [ "live.gain~[5]", "live.gain~[5]", 0 ],
			"obj-68" : [ "live.gain~", "live.gain~", 0 ],
			"obj-84" : [ "live.gain~[1]", "live.gain~", 0 ],
			"obj-85" : [ "live.gain~[2]", "live.gain~", 0 ],
			"obj-86" : [ "live.gain~[3]", "live.gain~", 0 ],
			"obj-87" : [ "live.gain~[4]", "live.gain~", 0 ],
			"parameterbanks" : 			{
				"0" : 				{
					"index" : 0,
					"name" : "",
					"parameters" : [ "-", "-", "-", "-", "-", "-", "-", "-" ]
				}

			}
,
			"inherited_shortname" : 1
		}
,
		"dependency_cache" : [ 			{
				"name" : "10353673376_ec7a400972_b.jpg",
				"bootpath" : "~/Downloads",
				"patcherrelativepath" : "../../Downloads",
				"type" : "JPEG",
				"implicit" : 1
			}
 ],
		"autosave" : 0
	}

}
