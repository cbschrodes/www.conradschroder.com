#!/usr/bin/env python3
"""
SNIPER CHECK - Robust Financial Stock Analysis Tool
Version: 4.1.0 (Hotfix: Attribute Repair & ROIC Standardization)

Author: Conrad Schroder
"""

import warnings
warnings.simplefilter(action='ignore', category=FutureWarning)
import sys
import concurrent.futures
import logging
import statistics
import uuid
import warnings
from decimal import Decimal, InvalidOperation, getcontext
from dataclasses import dataclass
from typing import Optional, Dict, List, Any

# Strict Dependency Check
try:
    import yfinance as yf
    import pandas as pd
    import numpy as np
except ImportError as e:
    sys.stderr.write(f"[CRITICAL] Missing Dependency: {e}\n")
    sys.exit(1)

# SILENCE PANDAS WARNINGS
warnings.simplefilter(action='ignore', category=FutureWarning)

# =============================================================================
# 1. ENTERPRISE CONFIGURATION
# =============================================================================

getcontext().prec = 28

CONSTANTS = {
    'MAX_ACCEPTABLE_PEG': Decimal('1.5'),
    'MAX_EV_EBITDA': Decimal('12.0'),
    'MIN_ROIC': Decimal('0.15'),  # 15% ROIC target
    'MAX_NET_DEBT_EBITDA': Decimal('3.0'),
    'MIN_FCF_YIELD': Decimal('0.05'), # 5% FCF Yield
}

SECTOR_PEERS = {
    'TECHNOLOGY': ['AAPL', 'MSFT', 'NVDA', 'ORCL', 'ADBE', 'CRM', 'CSCO', 'ACN'],
    'FINANC': ['JPM', 'BAC', 'WFC', 'MS', 'GS', 'C', 'BLK', 'AXP'],
    'HEALTH': ['LLY', 'UNH', 'JNJ', 'MRK', 'ABBV', 'TMO', 'PFE', 'AMGN'],
    'CYCLICAL': ['AMZN', 'TSLA', 'HD', 'MCD', 'NKE', 'SBUX', 'LOW', 'BKNG'],
    'DEFENSIVE': ['WMT', 'PG', 'COST', 'KO', 'PEP', 'PM', 'EL', 'CL'],
    'ENERGY': ['XOM', 'CVX', 'SHEL', 'TTE', 'COP', 'BP', 'SLB', 'EOG'],
    'INDUST': ['CAT', 'GE', 'UNP', 'HON', 'UPS', 'BA', 'LMT', 'RTX'],
    'COMMUNICATION': ['GOOGL', 'META', 'NFLX', 'DIS', 'CMCSA', 'TMUS', 'VZ', 'T'],
    'UTIL': ['NEE', 'SO', 'DU', 'D', 'AEP', 'PCG', 'EXC', 'SRE'],
    'ESTATE': ['PLD', 'AMT', 'EQIX', 'CCI', 'PSA', 'O', 'VICI', 'DLR'],
    'MATERIAL': ['LIN', 'SHW', 'FCX', 'CTVA', 'ECL', 'NEM', 'APD', 'DOW'],
    'DEFAULT': ['SPY']
}

# =============================================================================
# 2. LOGGING KERNEL
# =============================================================================

class EnterpriseLogger:
    def __init__(self):
        self._logger = logging.getLogger('Analysis')
        self._logger.setLevel(logging.INFO)
        if not self._logger.handlers:
            formatter = logging.Formatter('%(asctime)s | %(levelname)s | [%(req_id)s] | %(message)s')
            ch = logging.StreamHandler()
            ch.setFormatter(formatter)
            self._logger.addHandler(ch)

    def log(self, level: str, msg: str, req_id: str = "SYS"):
        extra = {'req_id': req_id}
        if level == 'INFO': self._logger.info(msg, extra=extra)
        elif level == 'WARN': self._logger.warning(msg, extra=extra)
        elif level == 'ERROR': self._logger.error(msg, extra=extra)

elog = EnterpriseLogger()

# =============================================================================
# 3. MATH KERNEL
# =============================================================================

class FinMath:
    @staticmethod
    def to_decimal(val: Any) -> Optional[Decimal]:
        if val is None: return None
        if isinstance(val, (float, int)): val = str(val)
        try:
            clean = str(val).replace(',', '').replace('$', '').replace('%', '').strip()
            if clean.lower() in ['nan', 'inf', 'none', '']: return None
            return Decimal(clean)
        except InvalidOperation:
            return None

    @staticmethod
    def safe_div(num: Optional[Decimal], den: Optional[Decimal]) -> Optional[Decimal]:
        if num is None or den is None or den == Decimal('0'):
            return None
        return num / den

# =============================================================================
# 4. DATA INGESTION (With Threading)
# =============================================================================

class MarketDataGateway:
    def fetch_basic_info(self, ticker: str) -> Dict[str, Any]:
        try:
            dat = yf.Ticker(ticker)
            return dat.info
        except Exception:
            return {}

    def fetch_full_financials(self, ticker: str, req_id: str):
        elog.log("INFO", f"Deep diving financials for {ticker}...", req_id)
        try:
            t = yf.Ticker(ticker)
            return {
                'info': t.info,
                'balance_sheet': t.balance_sheet,
                'financials': t.financials,
                'cashflow': t.cashflow
            }
        except Exception as e:
            elog.log("ERROR", f"Financials fetch failed: {e}", req_id)
            return None

# =============================================================================
# 5. COMPS ENGINE
# =============================================================================

@dataclass
class RelativeValuation:
    ticker: str
    peer_group: List[str]
    target_ev_ebitda: Optional[Decimal]
    peer_median_ev_ebitda: Optional[Decimal]
    premium_discount_pct: Optional[Decimal]
    percentile_rank: str

class CompsEngine:
    def __init__(self, gateway: MarketDataGateway):
        self.gateway = gateway

    def get_peer_group(self, sector: str) -> List[str]:
        if not sector: return SECTOR_PEERS['DEFAULT']
        sec_upper = sector.upper()
        for key, peers in SECTOR_PEERS.items():
            if key in sec_upper: return peers
        return SECTOR_PEERS['DEFAULT']

    def analyze_peers(self, target_ticker: str, target_sector: str, target_ev_ebitda: Optional[Decimal], req_id: str) -> RelativeValuation:
        peers = self.get_peer_group(target_sector)
        elog.log("INFO", f"Parallel fetch for {len(peers)} peers...", req_id)
        
        ev_multiples = []

        with concurrent.futures.ThreadPoolExecutor(max_workers=5) as executor:
            future_to_peer = {executor.submit(self.gateway.fetch_basic_info, peer): peer for peer in peers if peer != target_ticker}
            
            for future in concurrent.futures.as_completed(future_to_peer):
                try:
                    data = future.result()
                    ev = FinMath.to_decimal(data.get('enterpriseValue'))
                    ebitda = FinMath.to_decimal(data.get('ebitda'))
                    ratio = FinMath.safe_div(ev, ebitda)
                    
                    if ratio and 0 < ratio < 100:
                        ev_multiples.append(ratio)
                except Exception:
                    continue

        if not ev_multiples:
            return RelativeValuation(target_ticker, peers, None, None, None, "Insufficient Data")

        median_ev = Decimal(statistics.median(ev_multiples))
        prem_disc = None
        rank_msg = "N/A"

        if target_ev_ebitda:
            diff = target_ev_ebitda - median_ev
            prem_disc = (diff / median_ev) * 100
            
            sorted_ev = sorted(ev_multiples)
            n = len(sorted_ev)
            if n > 0:
                rank = sum(1 for x in sorted_ev if x < target_ev_ebitda)
                pct_rank = (rank / n) * 100
                rank_msg = f"Cheaper than {100-pct_rank:.0f}% of peers" if pct_rank < 50 else f"More expensive than {pct_rank:.0f}% of peers"

        return RelativeValuation(
            ticker=target_ticker,
            peer_group=peers,
            target_ev_ebitda=target_ev_ebitda,
            peer_median_ev_ebitda=median_ev,
            premium_discount_pct=prem_disc,
            percentile_rank=rank_msg
        )

# =============================================================================
# 6. MAIN ENGINE
# =============================================================================

@dataclass
class StockAudit:
    ticker: str
    price: Decimal
    pegy: Optional[Decimal]
    ev_ebitda: Optional[Decimal]
    
    # New Metrics
    roic: Optional[Decimal]
    net_debt_ebitda: Optional[Decimal]
    fcf_yield: Optional[Decimal]
    piotroski_score: int
    
    comps: RelativeValuation
    verdict: str
    score_card: int

class SniperEngine:
    def __init__(self):
        self.gateway = MarketDataGateway()
        self.comps_engine = CompsEngine(self.gateway)

    def calculate_piotroski(self, financial_data: Dict) -> int:
        score = 0
        try:
            bs = financial_data['balance_sheet']
            fin = financial_data['financials']
            cf = financial_data['cashflow']
            
            if bs.shape[1] < 2 or fin.shape[1] < 2 or cf.shape[1] < 2:
                return -1

            curr_ni = fin.iloc[:, 0].get('Net Income', 0)
            curr_roa = curr_ni / bs.iloc[:, 0].get('Total Assets', 1)
            op_cash = cf.iloc[:, 0].get('Operating Cash Flow', 0)
            
            if curr_roa > 0: score += 1
            if op_cash > 0: score += 1
            if op_cash > curr_ni: score += 1

            curr_leverage = bs.iloc[:, 0].get('Long Term Debt', 0)
            prev_leverage = bs.iloc[:, 1].get('Long Term Debt', 0)
            if curr_leverage < prev_leverage: score += 1
            
            curr_ratio = bs.iloc[:, 0].get('Current Assets', 0) / bs.iloc[:, 0].get('Current Liabilities', 1)
            prev_ratio = bs.iloc[:, 1].get('Current Assets', 0) / bs.iloc[:, 1].get('Current Liabilities', 1)
            if curr_ratio > prev_ratio: score += 1

            curr_gm = (fin.iloc[:, 0].get('Gross Profit', 0) / fin.iloc[:, 0].get('Total Revenue', 1))
            prev_gm = (fin.iloc[:, 1].get('Gross Profit', 0) / fin.iloc[:, 1].get('Total Revenue', 1))
            if curr_gm > prev_gm: score += 1

            return score
        except Exception:
            return 0

    def analyze(self, ticker: str) -> Optional[StockAudit]:
        req_id = uuid.uuid4().hex[:8]
        data_pack = self.gateway.fetch_full_financials(ticker, req_id)
        if not data_pack: return None
        
        info = data_pack['info']
        price = FinMath.to_decimal(info.get('currentPrice'))
        mkt_cap = FinMath.to_decimal(info.get('marketCap'))
        if not price or not mkt_cap: return None

        # --- ROIC (Book Value Standard) ---
        roic = None
        try:
            ebitda = FinMath.to_decimal(info.get('ebitda'))
            ebit = ebitda # Proxy if EBIT missing
            tax_rate = Decimal('0.21')
            nopat = ebit * (1 - tax_rate)
            
            total_debt = FinMath.to_decimal(info.get('totalDebt'))
            total_cash = FinMath.to_decimal(info.get('totalCash'))
            
            # FIXED: Use Book Equity, not Market Cap
            book_equity = FinMath.to_decimal(info.get('totalStockholderEquity'))
            if not book_equity:
                 # Fallback to bookValue * shares if direct field missing
                 book_equity = FinMath.to_decimal(info.get('bookValue')) * FinMath.to_decimal(info.get('sharesOutstanding'))

            invested_capital = (total_debt + book_equity) - total_cash
            roic = FinMath.safe_div(nopat, invested_capital)
        except:
            pass

        # --- Net Debt / EBITDA ---
        nd_ebitda = None
        try:
            total_debt = FinMath.to_decimal(info.get('totalDebt'))
            total_cash = FinMath.to_decimal(info.get('totalCash'))
            ebitda = FinMath.to_decimal(info.get('ebitda'))
            net_debt = total_debt - total_cash
            nd_ebitda = FinMath.safe_div(net_debt, ebitda)
        except:
            pass

        # --- FCF Yield ---
        fcf_yield = None
        try:
            fcf = FinMath.to_decimal(info.get('freeCashflow'))
            fcf_yield = FinMath.safe_div(fcf, mkt_cap)
        except:
            pass
            
        # --- Piotroski F-Score ---
        f_score = self.calculate_piotroski(data_pack)

        # --- EV / EBITDA & PEGY ---
        ev_ebitda = None
        if nd_ebitda and ebitda:
            ev = mkt_cap + (total_debt - total_cash)
            ev_ebitda = FinMath.safe_div(ev, ebitda)

        pe = FinMath.to_decimal(info.get('trailingPE'))
        peg = FinMath.to_decimal(info.get('pegRatio'))
        div = FinMath.to_decimal(info.get('dividendYield')) or Decimal(0)
        
        pegy = None
        if peg:
            growth = FinMath.safe_div(pe, peg)
            if growth:
                pegy = FinMath.safe_div(pe, (growth + (div * 100)))

        # --- Run Comps ---
        comps = self.comps_engine.analyze_peers(ticker, info.get('sector'), ev_ebitda, req_id)

        # --- Scoring ---
        points = 0
        if roic and roic > CONSTANTS['MIN_ROIC']: points += 1
        if nd_ebitda and nd_ebitda < CONSTANTS['MAX_NET_DEBT_EBITDA']: points += 1
        if fcf_yield and fcf_yield > CONSTANTS['MIN_FCF_YIELD']: points += 1
        if pegy and pegy < Decimal('1.2'): points += 1
        if f_score >= 6: points += 1
        
        verdict = "HOLD / WATCH"
        if points >= 4: verdict = "STRONG BUY (Quality + Value)"
        elif points <= 1: verdict = "AVOID / SELL (Fundamental Flaws)"

        return StockAudit(
            ticker=ticker,
            price=price,
            pegy=pegy,
            ev_ebitda=ev_ebitda,
            roic=roic,
            net_debt_ebitda=nd_ebitda,
            fcf_yield=fcf_yield,
            piotroski_score=f_score,
            comps=comps,
            verdict=verdict,
            score_card=points
        )

# =============================================================================
# 7. REPORTING LAYER
# =============================================================================

def print_audit_report(a: StockAudit):
    c = a.comps
    
    print("\n" + "█"*70)
    print(f" SNIPER AUDIT v4.1: {a.ticker} ".center(70, "█"))
    print("█"*70)
    print(f" VERDICT: {a.verdict} (Score: {a.score_card}/5)")
    print(f" PRICE:   ${a.price:,.2f}")
    print("-" * 70)
    
    # 1. QUALITY & SAFETY
    print(" [1] QUALITY & SAFETY")
    r_disp = f"{a.roic*100:.1f}%" if a.roic else "N/A"
    print(f" • ROIC (Moat):          {r_disp:<10} (Target > 15%)")
    
    # FIXED: Attribute access match
    fs_disp = f"{a.piotroski_score}/9" if a.piotroski_score >= 0 else "N/A"
    print(f" • Piotroski F-Score:    {fs_disp:<10} (Target > 6)")
    
    debt_disp = f"{a.net_debt_ebitda:.2f}x" if a.net_debt_ebitda else "N/A"
    print(f" • Net Debt/EBITDA:      {debt_disp:<10} (Target < 3.0x)")

    print("-" * 70)
    
    # 2. VALUATION (Absolute)
    print(" [2] VALUATION (Absolute)")
    fcf_disp = f"{a.fcf_yield*100:.1f}%" if a.fcf_yield else "N/A"
    print(f" • FCF Yield:            {fcf_disp:<10} (Target > 5%)")
    
    pegy_disp = f"{a.pegy:.2f}" if a.pegy else "N/A"
    print(f" • PEGY Ratio:           {pegy_disp:<10} (Target < 1.0)")
    
    print("-" * 70)

    # 3. VALUATION (Relative/Comps)
    print(" [3] VALUATION (Relative to Peers)")
    print(f" • Sector Peers: {len(c.peer_group)} companies")
    
    if c.premium_discount_pct:
        p_d = "PREMIUM" if c.premium_discount_pct > 0 else "DISCOUNT"
        print(f" • Target EV/EBITDA:     {c.target_ev_ebitda:.2f}x")
        print(f" • Peer Median:          {c.peer_median_ev_ebitda:.2f}x")
        print(f" • Status:               Trading at {abs(c.premium_discount_pct):.1f}% {p_d} to Median")
        print(f" • Rank:                 {c.percentile_rank}")
    else:
        print(" • Comps Data: Insufficient")
        
    print("="*70 + "\n")

if __name__ == "__main__":
    tool = SniperEngine()
    targets = sys.argv[1:] if len(sys.argv) > 1 else ['JPM', 'GOOGL']
    
    print(f"Starting analysis on: {targets}")
    for t in targets:
        result = tool.analyze(t)
        if result:
            print_audit_report(result)
